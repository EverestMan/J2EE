package com.despat;

class MessageImpl implements Message
{

	@Override
	public  void dispWhatsAppMessage() {
		System.out.println("Whats App Message!");
	}
	@Override
	public  void dispMessage() {
		System.out.println("Text Message!");
	}
}