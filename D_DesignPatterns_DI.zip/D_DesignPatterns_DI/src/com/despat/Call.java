package com.despat;

public interface Call {

	void makeWhatsAppCall();

	void makeCall();

	void makeVideoCall();

}