/*Class Name : MessagingSystem
Purpose : A ban..
Author : SP
Creation Date : 12/12/2016
Modified Date : Nil*/

package com.despat;

public class CommunicationSystem {
	public static void main(String[] args) {

		Configurartion configurartion = new Configurartion();
		configurartion.configure();
		MessageBean message = configurartion.getMessageBean();
		message.dispMessage();
		//message.dispWhatsAppMessage();
		
		/*Message message = new MessageImpl();
		message.dispMessage();
		message.dispWhatsAppMessage();*/

		/*Call call = new CallImpl();
		call.makeCall();
		call.makeVideoCall();
		call.makeWhatsAppCall();

		Communicate communicate = new CommunicateImpl();
		communicate.dispMessage();
		communicate.dispWhatsAppMessage();
		communicate.makeCall();
		communicate.makeVideoCall();
		communicate.makeWhatsAppCall();*/

	}
}