package com.despat;

interface Message {

	void dispWhatsAppMessage();

	void dispMessage();

}