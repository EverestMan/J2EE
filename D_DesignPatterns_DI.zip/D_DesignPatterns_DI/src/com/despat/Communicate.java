package com.despat;

public interface Communicate extends Call, Message{

}



