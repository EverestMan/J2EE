package com.despat;

public class CallImpl implements Call  {
	@Override
	public  void makeWhatsAppCall() {
		System.out.println("Whats App Call!");
	}
	@Override
	public  void makeCall() {
		System.out.println("Audio Call");
	}
	@Override
	public  void makeVideoCall() {
		System.out.println("Video Call");
	}
}
