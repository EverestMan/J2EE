package com.despat;

public class Configurartion{
	static MessageBean messageBean = null;	
	public static void configure(){
		messageBean = new MessageBean();
	}
	public  void setMessageBean(MessageBean messageBean) {
		Configurartion.messageBean = messageBean;
	}
	public  MessageBean getMessageBean() {
		return messageBean;
	}
}
