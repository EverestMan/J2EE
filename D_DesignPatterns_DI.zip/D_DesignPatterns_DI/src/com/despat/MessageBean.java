package com.despat;

public class MessageBean {
	private Message message;
	public MessageBean(){
		//message = new MessageImpl();
		message = new MessageEmoticons();
	}
	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
	void dispWhatsAppMessage(){
		message.dispWhatsAppMessage();
	}

	void dispMessage(){
		message.dispMessage();
	}

}
