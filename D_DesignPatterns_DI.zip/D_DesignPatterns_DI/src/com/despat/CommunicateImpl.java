package com.despat;

public class CommunicateImpl implements Communicate{
	CallImpl callImpl = null;
	MessageImpl messageImpl = null;
	public CommunicateImpl(){
		callImpl = new CallImpl();
		messageImpl = new MessageImpl();
	}
	@Override
	public void makeWhatsAppCall() {
		callImpl.makeWhatsAppCall();
	}

	@Override
	public void makeCall() {
		callImpl.makeCall();
	}

	@Override
	public void makeVideoCall() {
		callImpl.makeVideoCall();
	}

	@Override
	public void dispWhatsAppMessage() {
		messageImpl.dispWhatsAppMessage();
	}

	@Override
	public void dispMessage() {
		messageImpl.dispMessage();
	}

}
