
package com.spring4.model;

public class Employee {

	private String name = "Rambo!";

	public String getName() {
		return name;
	}

	public void setName(String nm) {
		this.name = nm;
	}

	public void details() {
		System.out.println("Employee > Iniside details() : " + name);
	}
}
