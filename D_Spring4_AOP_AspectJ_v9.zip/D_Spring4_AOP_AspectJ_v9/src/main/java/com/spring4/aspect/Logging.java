/*An aspect is a class that implements enterprise application concerns
that cut across multiple classes, such as transaction management.*/
/*Pointcut are expressions that is matched with join points to determine 
whether advice needs to be executed or not. */
/*Advices are actions taken for a particular join point. In terms of programming, 
they are methods that gets executed when a certain join point with matching pointcut
is reached in the application. */
/*A join point is the specific point in the application such as method execution, 
exception handling, changing object variable values etc. 
In Spring AOP a join points is always the execution of a method.*/

/*Before Advice: These advices runs before the execution of join point methods. 
We can use @Before annotation to mark an advice type as Before advice.
After (finally) Advice: An advice that gets executed after the join point method finishes executing,
whether normally or by throwing an exception. We can create after advice using @After annotation.
After Returning Advice: Sometimes we want advice methods to execute only if the join point method 
executes normally. We can use @AfterReturning annotation to mark a method as after returning advice.
After Throwing Advice: This advice gets executed only when join point method throws exception, 
we can use it to rollback the transaction declaratively.
We use @AfterThrowing annotation for this type of advice.
Around Advice: This is the most important and powerful advice. 
This advice surrounds the join point method. */

package com.spring4.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect 
public class Logging{  

    @Pointcut("execution(* com.spring4.model.Employee.set*(String))")// The Pointcut Expression  
    public void allEmployeeMethodPointCut(){}//The Pointcut Name
      
    @Before("allEmployeeMethodPointCut()")//Applying Pointcut on Before advice. 
    public void beforeAdvice(JoinPoint jp)//The Before Advice 
    {  
        System.out.println("Before : " +  jp.getSignature());  

    } 
    @After("allEmployeeMethodPointCut()")//Applying Pointcut on Before advice. 
    public void afterAdvice(JoinPoint jp)//The Before Advice 
    {  
        System.out.println("After : " +  jp.getSignature());  

    } 
}  