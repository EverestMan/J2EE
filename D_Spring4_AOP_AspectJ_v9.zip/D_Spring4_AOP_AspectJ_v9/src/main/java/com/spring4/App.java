package com.spring4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring4.model.Employee;

public class App {
	 public static void main(String[] args){  
	        ApplicationContext context = null;
	        context = new ClassPathXmlApplicationContext("applicationContext.xml");  
	        Employee employee = (Employee) context.getBean("employee");   
	        //employee.details();
	        employee.setName("John");
	        //employee.details();
	    }  
}
