package com.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Response;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.orm.model.Employee;
import com.orm.util.HibernateUtil;

@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().println("Saving!");
		 saveEmployee("Jumbo1", "MGR", 30000, 10); 
		 saveEmployee("Spring1", "CLERK", 10000, 30); 
		 saveEmployee("Hibernate1", "SALESMAN", 8000, 10);	
		 response.getWriter().println("Saved!");
		 
	}
	public static void saveEmployee(String ename, String job, int sal, int deptno) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();
			Employee emp = new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.save(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			System.out.println(e);
		} finally {
			session.close();
		}

	}
}
