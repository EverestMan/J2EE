package com.spring4;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.spring4.configuration.Spring4Configuration;
import com.spring4.domain.Communication;

public class App {
	public static void main(String[] args) {
		AbstractApplicationContext abstractApplicationContext = null;
		abstractApplicationContext = new AnnotationConfigApplicationContext(Spring4Configuration.class);
		// abstractApplicationContext = new
		// ClassPathXmlApplicationContext("Spring4Configuration.xml");

		/*
		 * Call call = (Call)abstractApplicationContext.getBean("callBean");
		 * call.makeWhatsAppCall(); call.makeCall(); call.makeVideoCall();
		 * 
		 * Message message =
		 * (Message)abstractApplicationContext.getBean("messageBean");
		 * message.dispMessage(); message.dispWhatsAppMessage();
		 */

		// Constructor based DI
		Communication communication = (Communication) abstractApplicationContext.getBean("communicationBean");
		communication.communicate();

	}
}
