package com.spring4.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spring4.domain.Call;
import com.spring4.domain.CallImpl;
import com.spring4.domain.Message;
import com.spring4.domain.MessageEmoticons;

@Configuration
public class Spring4Configuration {
	@Bean(name = "callBean")
	public Call getCall() {
		return new CallImpl();
	}

	@Bean(name = "messageBean")
	public Message getMessage() {
		return new MessageEmoticons();
		//return new MessageImpl();
	}
}
