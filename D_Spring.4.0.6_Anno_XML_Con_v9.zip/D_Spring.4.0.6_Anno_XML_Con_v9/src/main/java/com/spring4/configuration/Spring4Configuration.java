package com.spring4.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spring4.domain.Call;
import com.spring4.domain.CallImpl;
import com.spring4.domain.Communication;
import com.spring4.domain.Message;
import com.spring4.domain.MessageImplEmoticons;

@Configuration
public class Spring4Configuration {
	@Bean(name = "callBean")
	public Call getCall() {
		return new CallImpl();
	}
	@Bean(name = "messageBean")
	public Message getMessage() {
		return new MessageImplEmoticons();
		//return new MessageImpl();
	}	
	@Bean(name = "communicationBean")
	public Communication getCommunication() {
		Communication communication = null;
		//Constructor Based DI
		//communication = new Communication(getMessage());
		//Setter based DI
		communication = new Communication();
		communication.setMessage(getMessage());
		return communication;
	}
}
