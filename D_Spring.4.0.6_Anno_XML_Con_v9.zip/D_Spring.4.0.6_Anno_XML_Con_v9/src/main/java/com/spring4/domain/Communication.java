package com.spring4.domain;

public class Communication {
	private Message message = null;

	public Communication() {
		System.out.println("Cons!");
	}

	public Communication(Message message) {
		this.message = message;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public void communicate() {
		message.dispMessage();
	}
}
