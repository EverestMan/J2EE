package com.spring4.domain;

public interface Message {

	void dispWhatsAppMessage();

	void dispMessage();

}