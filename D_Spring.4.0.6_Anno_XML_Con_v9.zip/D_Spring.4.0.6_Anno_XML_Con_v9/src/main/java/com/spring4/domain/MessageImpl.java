package com.spring4.domain;

public class MessageImpl implements Message
{

	@Override
	public  void dispWhatsAppMessage() {
		System.out.println("Whats App Message!");
	}
	@Override
	public  void dispMessage() {
		System.out.println("Text Message!");
	}
}