package com.spring4.domain;

public interface Call {

	void makeWhatsAppCall();

	void makeCall();

	void makeVideoCall();

}