package com.orm;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.orm.model.Employee;
import com.orm.util.HibernateUtil;

public class Main {
	public static void main(String[] args) {
		
		 saveEmployee("Jumbo", "MGR", 30000, 10); 
		 saveEmployee("Spring", "CLERK", 10000, 30); 
		 saveEmployee("Hibernate", "SALESMAN", 8000, 10);	 
		//retriveEmployee();
		//deleteEmployee(1);
		//updateEmployee(2, 60000);
		retriveEmployee();
	}

	public static void saveEmployee(String ename, String job, int sal, int deptno) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();
			Employee emp = new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.save(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			System.out.println(e);
		} finally {
			session.close();
		}

	}

	public static void retriveEmployee()
	{

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			//transaction = session.beginTransaction();
			List employee = session.createQuery("from Employee").list();

			for (Iterator iterator = employee.iterator(); iterator.hasNext();) {
				Employee employee1 = (Employee) iterator.next();
				System.out.println(employee1.getEmpno() + "  " + employee1.getEname() + "  " + employee1.getJob()
						+ "   " + employee1.getSal() + "   " + employee1.getDeptno());
			}
			//transaction.commit();

		} catch (HibernateException e) {

			//transaction.rollback();

			System.out.println(e);

		} finally {

			session.close();

		}
	}

	public static void updateEmployee(int empno, int sal) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			String queryString = "from Employee where empno = :empno";
			Query query = session.createQuery(queryString);
			query.setInteger("empno", empno);
			Employee employee = (Employee) query.uniqueResult();
			employee.setSal(sal);
			session.update(employee);
			transaction.commit();
			System.out.println("One employee is updated!");
		} catch (HibernateException e) {

			transaction.rollback();

			System.out.println(e);

		} finally {

			session.close();

		}
	}

	public static void deleteEmployee(int empno) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			String queryString = "from Employee where empno = :empno";
			org.hibernate.Query query = session.createQuery(queryString);
			query.setInteger("empno", empno);
			Employee employee = (Employee) query.uniqueResult();
			session.delete(employee);

			// Another way to write it
			/*
			 * String hql = "delete from Employee insurance where deptno = 30";
			 * Query query1 = session.createQuery(hql); int row =
			 * query1.executeUpdate(); if (row == 0){
			 * System.out.println("Doesn't deleted any row!"); } else{
			 * System.out.println("Deleted Row: " + row); }
			 */
			transaction.commit();
			System.out.println("One employee is deleted!");

		} catch (HibernateException e) {

			transaction.rollback();

			System.out.println(e);

		} finally {

			session.close();
		}
	}
}
